<?php
    require "conection.php";
    $id = $_GET['id'];
    $ime = $_POST['ime'];
    $email = $_POST['email'];
    $telefon = $_POST['telefon'];
    $adresa = $_POST['adresa'];
    

    

    $sql="UPDATE korisnici SET ime='$ime',email='$email',telefon='$telefon',adresa='$adresa' WHERE id= '$id'";
    $stmt=$pdo->prepare($sql);
    $stmt->execute();
    
    
    header("Location: http://127.0.0.1/WSIT/admin.php");

?>

