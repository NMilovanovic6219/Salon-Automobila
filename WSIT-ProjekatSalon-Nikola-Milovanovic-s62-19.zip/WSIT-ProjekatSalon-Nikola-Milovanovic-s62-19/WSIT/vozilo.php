<?php
	        require 'conection.php';
          session_start();
	        $sql="SELECT * FROM korisnici";
	        $stmt=$pdo-> query($sql);
          $korisnici=$stmt->fetchAll(PDO::FETCH_ASSOC);
          
          $sql="SELECT * FROM servis";
	        $stmt=$pdo-> query($sql);
	        $servis=$stmt->fetchAll(PDO::FETCH_ASSOC);
	        
   		?> 

           
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Pocetna</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
  <script src="script.js"></script>
    <style>
       

        .div5
        {
            height: 1500px;
            
        }
        

        
        body {
            background: url('Slike/prava.svg') no-repeat center center fixed;
            -webkit-background-size: cover;
            -moz-background-size: cover;
            background-size: cover;
            -o-background-size: cover;
        }
        .red
        {
            background-color: #222831!important;
        }
        .green
        {
            color: silver;
            font-size: 75px;
            margin-left: 220px;
            margin-top: 50px;
        }
       

        body {font-family: Arial, Helvetica, sans-serif;}


input[type=text], input[type=password] {
  width: 100%;
  padding: 12px 20px;
  margin: 8px 0;
  display: inline-block;
  border: 1px solid #ccc;
  box-sizing: border-box;
}


button {
  background-color: #222831;
  color: white;
  color: #9d9d9d;
  margin: 8px 0;
  border: none;
  cursor: pointer;
  width: 100%;
}

button:hover {
  opacity: 0.8;
}


.cancelbtn {
  width: auto;
  padding: 10px 18px;
  background-color: #f44336;
}


.imgcontainer {
  text-align: center;
  margin: 24px 0 12px 0;
  position: relative;
}

img.avatar {
  width: 40%;
  border-radius: 50%;
}

.container {
  padding: 16px;
}

span.psw {
  float: right;
  padding-top: 16px;
}


.modal {
  display: none; 
  position: fixed; 
  z-index: 1; 
  left: 0;
  top: 0;
  width: 100%; 
  height: 100%; 
  overflow: auto; 
  background-color: rgb(0,0,0); 
  background-color: rgba(0,0,0,0.4); 
  padding-top: 60px;
}


.modal-content {
  background-color: #fefefe;
  margin: 5% auto 15% auto; 
  border: 1px solid #888;
  width: 80%; 
}


.close {
  position: absolute;
  right: 25px;
  top: 0;
  color: #000;
  font-size: 35px;
  font-weight: bold;
}

.close:hover,
.close:focus {
  color: red;
  cursor: pointer;
}


.animate {
  -webkit-animation: animatezoom 0.6s;
  animation: animatezoom 0.6s
}

@-webkit-keyframes animatezoom {
  from {-webkit-transform: scale(0)} 
  to {-webkit-transform: scale(1)}
}
  
@keyframes animatezoom {
  from {transform: scale(0)} 
  to {transform: scale(1)}
}


@media screen and (max-width: 300px) {
  span.psw {
     display: block;
     float: none;
  }
  .cancelbtn {
     width: 100%;
  }
}
.dugme
{
    width:auto;
    height:35px;
    font-size: 18px!important;

}
.naslov
{
    font-size: 20px;
    margin-left: 50px;
    margin-top: 50px;
    color: silver;
}

.naslov2
{
    font-size: 14px;
    margin-left: 50px;
    margin-top: 50px;
    color: silver;
}
.input
{
    color: silver;
}
.label
{
    color: silver;
    font-size: 14px;
}
.prova
{
    margin-bottom: 45px;
}

.table
{
   color: silver;
}

.oci
{
    margin-top: 50px;
    
    height: 400px;
}
.oci2
{
    
    
    height: 399px;
}
.oci3
{
    
    
    height: 399px;
    background-image: url('Slike/21.jpg');
    background-size: cover;
}
.oci4
{
    
    
    height: 399px;
}
.oci5
{
    
    
    height: 399px;
    background-image: url('Slike/22.jpg');
    background-size: cover;
}
.oci6
{
    
    
    height: 399px;
}
.oci7
{
    
    
    height: 399px;
    background-image: url('Slike/24.PNG');
    background-size: cover;
}
.pt
{
    font-size: 40px;
    color: silver;
}
.pn
{
    font-size: 18px;
    color: silver;
}
.naslov3
{
    font-size: 30px;
    margin-top: 30px;
    color: silver;
}
    </style>
</head>
<body>

<div class="container">
<div class="row">
<nav class="red navbar navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header">
      <a class="glavni navbar-brand" href="http://localhost/WSIT/index.php">VOLVO</a>
    </div>
    <ul class="nav navbar-nav">
    <li><a href="http://localhost/WSIT/vozila.php">VOZILA</a>
        
      </li>
      <li><a href="http://localhost/WSIT/servis.php">SERVIS</a>
        
      </li>
      
    </ul>
    <ul class="nav navbar-nav navbar-right">





    <?php if(!$_SESSION):?>
        
        <button onclick="document.getElementById('id01').style.display='block'" class="dugme"><i class="bi bi-box-arrow-right"></i>
        Registruj se
        </button>
      <?php else:?>
        <?php if($_SESSION['isAdmin']):?>
          <button id="admin" class="dugme"><i class="bi bi-box-arrow-right"></i>
          Admin
        </button>
        <?php endif;?>
        
        <button id="logout" class="dugme"><i class="bi bi-box-arrow-right"></i>
        Izloguj se
        </button>
        
    <?php endif;?>

<div id="id01" class="modal">

<form class="modal-content animate" action="reg.php" method="POST">
<div class="imgcontainer">
<span onclick="document.getElementById('id01').style.display='none'" class="close" title="Close Modal">&times;</span>
<img src="Slike/4.PNG" alt="Avatar" class="avatar">
</div>

<div class="container">
<label for="ime"><b>Ime:</b></label>
<input type="text" placeholder="Unesite vase ime" name="ime" id="ime" required>

<label for="password"><b>Lozinka:</b></label>
<input type="password" placeholder="Unesite vasu lozinku" name="password" id="password" required>

<label for="email"><b>Email:</b></label>
<input type="text" placeholder="Unesite vas email" name="email" id="email" required>

<label for="telefon"><b>Telefon:</b></label>
<input type="text" placeholder="Unesite vas telefon" name="telefon" id="telefon" required>

<label for="adresa"><b>Adresa:</b></label>
<input type="text" placeholder="Unesite vasu adtesu" name="adresa" id="adresa" required>
  
<button type="submit">Registruj se</button>

</div>

</form>
</div>




    <?php if(!$_SESSION):?>
        
        <button onclick="document.getElementById('id02').style.display='block'" class="dugme"><i class="bi bi-box-arrow-right"></i>Uloguj se</button>
      
          
          <?php endif;?>
      <div id="id02" class="modal">
  
  <form class="modal-content animate" action="/action_page.php" method="post">
    <div class="imgcontainer">
      <span onclick="document.getElementById('id02').style.display='none'" class="close" title="Close Modal">&times;</span>
      <img src="Slike/4.PNG" alt="Avatar" class="avatar">
    </div>

    <div class="container">
      <label for="ime"><b>Ime:</b></label>
      <input type="text" placeholder="Unesite vase ime" name="ime" required>

      <label for="password"><b>Password</b></label>
      <input type="password" placeholder="Unesite vasu lozinku" name="password" required>
        
      <button type="submit" id="login">Login</button>
      
    </div>

  </form>
</div>
    </ul>
  </div>

  <!-- ---------------------------------------------------------------------------------------------------------- -->
  <div class="div5 col-lg-12">

  <p class="naslov3">VOLVO XC90 PREFINJENA, SNAZNA SUV VOZILA</p>

        <div class="oci col-lg-12">
            <div class="oci2 col-lg-4">
                
                <p class="pt">Napunite</p>
                <p class="pn">
                Elektromotor i benzinski motor rade usklađeno za vrhunski plug-in hibridni SUV, sa manjom emisijom izduvnih gasova, bolje performanse i veća snaga za Vas.
                </p>
            </div>

            <div class="oci3 col-lg-8">

            </div>
        </div>

        <div class="oci col-lg-12">
        <div class="oci5 col-lg-8">

        </div>

            <div class="oci4 col-lg-4">
                <p class="pt">Kabina za sve</p>
                    <p class="pn">
                    Čak i zajednički prostor zaslužuje lični prostor. Naše prostrane i udobne mogućnosti za sedenje do 7 putnika dizajnirane su za putovanja koja se najbolje dele.
                </p>
            </div>

           
        </div>


        <div class="oci col-lg-12">
            <div class="oci6 col-lg-4">
                
                    <p class="pt">Ruka pomoći</p>
                        <p class="pn">
                        Sistem prilagođavanja brzine u krivinama kontroliše i prilagođava Vašu brzinu kretanja za veću udobnost i preciznost u gotovo svim saobraćajnim uslovima.
                    </p>
                    
            </div>

            <div class="oci7 col-lg-8">

            </div>
        </div>









        
            </div>
            
             <div class="col-lg-12" style=" height: 500px; background-color: #222831;">
            <div class="col-lg-2" style=" height: 150px;">

            </div>

            <div class="col-lg-8" style="border-bottom: 2px solid  #2c698d; height: 150px;">
                <p class="green">VOLVO</p>
            </div>

            <div class="col-lg-2" style="height: 150px;">

            </div>
            <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d90696.87248172272!2d20.521207099312626!3d44.73435986509258!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x7fd51b4702d8675c!2z0KDQsNGH0YPQvdCw0YDRgdC60Lgg0YTQsNC60YPQu9GC0LXRgiDQo9C90LjQstC10YDQt9C40YLQtdGC0LAg0KPQvdC40L7QvQ!5e0!3m2!1sen!2srs!4v1610541392470!5m2!1sen!2srs" width="800" height="300"  frameborder="0" style="border:0; margin-left:170px; margin-top:20px" allowfullscreen="" aria-hidden="false" tabindex="0"></iframe>
            </div>
            </div>
            




</div>








        
            
            
        
    

</div>
</div>
</nav>




       
</div>

        
<script>
// Get the modal
var modal = document.getElementById('id01');

// When the user clicks anywhere outside of the modal, close it
window.onclick = function(event) {
    if (event.target == modal) {
        modal.style.display = "none";
    }
}
</script>


</body>
</html>
