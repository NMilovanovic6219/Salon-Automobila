<?php
    require "conection.php";
    $id = $_GET['id'];
    $poZelji = $_POST['poZelji'];
    $vozilo = $_POST['vozilo'];
    $godiste = $_POST['godiste'];
    $usr = $_POST['usr'];
    $prez = $_POST['prez'];
    $emailll = $_POST['emailll'];
    $telefonnn = $_POST['telefonnn'];
    $datum = $_POST['datum'];
    
    

    

    $sql="UPDATE servis SET poZelji='$poZelji',vozilo='$vozilo',godiste='$godiste',usr='$usr',prez='$prez',emailll='$emailll',telefonnn='$telefonnn',datum='$datum' WHERE id= '$id'";
    $stmt=$pdo->prepare($sql);
    $stmt->execute();
    
    
    header("Location: http://127.0.0.1/WSIT/admin.php");

?>

