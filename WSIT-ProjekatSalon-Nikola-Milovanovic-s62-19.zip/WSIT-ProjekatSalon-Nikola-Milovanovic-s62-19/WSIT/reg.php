<?php

require 'conection.php';

$ime = $_POST['ime'];
$password = $_POST['password'];
$email = $_POST['email'];
$telefon = $_POST['telefon'];
$adresa = $_POST['adresa'];

$sqlPrepare="INSERT INTO korisnici (ime,password,email,telefon,adresa) 
    VALUES (:ime, :password, :email, :telefon, :adresa)";
$stmt=$pdo->prepare($sqlPrepare);
$stmt->execute([
    'ime'=>$ime,
    'password' =>$password,
    'email'=>$email,
    'telefon'=> $telefon,
    'adresa'=> $adresa
]);

header("Location: http://127.0.0.1/WSIT");
?>