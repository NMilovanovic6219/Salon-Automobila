<?php
	        require 'conection.php';
          session_start();
	        $sql="SELECT * FROM korisnici";
	        $stmt=$pdo-> query($sql);
	        $korisnici=$stmt->fetchAll(PDO::FETCH_ASSOC);
	        
   		?> 

           
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Pocetna</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
  <script src="script.js"></script>
    <style>
        
        .div3
        {
            height: 700px;
            border: 2px solid red;
        }
        

        
        body {
            background: url('Slike/prava.svg') no-repeat center center fixed;
            -webkit-background-size: cover;
            -moz-background-size: cover;
            background-size: cover;
            -o-background-size: cover;
        }
        .red
        {
            background-color: #222831!important;
        }
        .green
        {
            color: silver;
            font-size: 75px;
            margin-left: 220px;
            margin-top: 50px;
        }
        .glavni
        {
            
        }

        body {font-family: Arial, Helvetica, sans-serif;}


input[type=text], input[type=password] {
  width: 100%;
  padding: 12px 20px;
  margin: 8px 0;
  display: inline-block;
  border: 1px solid #ccc;
  box-sizing: border-box;
}


button {
  background-color: #222831;
  color: white;
  color: #9d9d9d;
  margin: 8px 0;
  border: none;
  cursor: pointer;
  width: 100%;
}

button:hover {
  opacity: 0.8;
}


.cancelbtn {
  width: auto;
  padding: 10px 18px;
  background-color: #f44336;
}


.imgcontainer {
  text-align: center;
  margin: 24px 0 12px 0;
  position: relative;
}

img.avatar {
  width: 40%;
  border-radius: 50%;
}

.container {
  padding: 16px;
}

span.psw {
  float: right;
  padding-top: 16px;
}


.modal {
  display: none; 
  position: fixed; 
  z-index: 1; 
  left: 0;
  top: 0;
  width: 100%; 
  height: 100%; 
  overflow: auto; 
  background-color: rgb(0,0,0); 
  background-color: rgba(0,0,0,0.4); 
  padding-top: 60px;
}


.modal-content {
  background-color: #fefefe;
  margin: 5% auto 15% auto; 
  border: 1px solid #888;
  width: 80%; 
}


.close {
  position: absolute;
  right: 25px;
  top: 0;
  color: #000;
  font-size: 35px;
  font-weight: bold;
}

.close:hover,
.close:focus {
  color: red;
  cursor: pointer;
}


.animate {
  -webkit-animation: animatezoom 0.6s;
  animation: animatezoom 0.6s
}

@-webkit-keyframes animatezoom {
  from {-webkit-transform: scale(0)} 
  to {-webkit-transform: scale(1)}
}
  
@keyframes animatezoom {
  from {transform: scale(0)} 
  to {transform: scale(1)}
}


@media screen and (max-width: 300px) {
  span.psw {
     display: block;
     float: none;
  }
  .cancelbtn {
     width: 100%;
  }
}
.dugme
{
    width:auto;
    height:35px;
    font-size: 18px!important;

}

.filterDiv {
  float: left;
  height: 450px;
  text-align: center;
  display: none;
}

.show {
  display: block;
}

.container {
  margin-top: 20px;
  overflow: hidden;
}


.btn {
  border: none;
  outline: none;
  padding: 12px 16px;
  background-color: #f1f1f1;
  cursor: pointer;
  width: 90px;
  margin-top: 25px;
  margin-bottom: 20px;
  margin-left: 20px;
}

.btn:hover {
  background-color: #ddd;
}

.btn.active {
  background-color: #666;
  color: white;
}
.xc90p
{
    
    height: 280px;
    background-image: url('Slike/6.jpg');
    background-size: cover;
}
.xc90p2
{
    
    height: 280px;
    background-image: url('Slike/7.jpg');
    background-size: cover;
}

.xc60p
{
    
    height: 280px;
    background-image: url('Slike/8.jpg');
    background-size: cover;
}

.xc60p2
{
    
    height: 280px;
    background-image: url('Slike/9.PNG');
    background-size: cover;
}

.s90p
{
    
    height: 280px;
    background-image: url('Slike/10.jpg');
    background-size: cover;
}

.s90p2
{
    
    height: 280px;
    background-image: url('Slike/11.jpg');
    background-size: cover;
}

.s60p
{
    
    height: 280px;
    background-image: url('Slike/12.jpg');
    background-size: cover;
}

.s60p2
{
    
    height: 280px;
    background-image: url('Slike/13.jpg');
    background-size: cover;
}

.v90p
{
    
    height: 280px;
    background-image: url('Slike/16.jpg');
    background-size: cover;
}

.v90p2
{
    
    height: 280px;
    background-image: url('Slike/17.jpg');
    background-size: cover;
}

.v60p
{
    
    height: 280px;
    background-image: url('Slike/14.jpg');
    background-size: cover;
}

.v60p2
{
    
    height: 280px;
    background-image: url('Slike/15.jpg');
    background-size: cover;
}

.xc90t
{
    
    height: 169px;
}

.text1
{
  margin-top: 15px;
  color: silver;
}

.proba
{
  color: silver;
  text-decoration: none!important;
}

    </style>
</head>
<body>

<div class="container">
<div class="row">
<nav class="red navbar navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header">
      <a class="glavni navbar-brand" href="http://localhost/WSIT/index.php">VOLVO</a>
    </div>
    <ul class="nav navbar-nav">
    <li><a href="http://localhost/WSIT/vozila.php">VOZILA</a>
        
      </li>
      <li><a href="http://localhost/WSIT/servis.php">SERVIS</a>
        
      </li>
      
    </ul>
    <ul class="nav navbar-nav navbar-right">





    <?php if(!$_SESSION):?>
        
        <button onclick="document.getElementById('id01').style.display='block'" class="dugme"><i class="bi bi-box-arrow-right"></i>
        Registruj se
        </button>
      <?php else:?>
        <?php if($_SESSION['isAdmin']):?>
          <button id="admin" class="dugme"><i class="bi bi-box-arrow-right"></i>
          <a href="http://localhost/WSIT/admin.php">Admin</a>
        </button>
        <?php endif;?>

        <button id="logout" class="dugme"><i class="bi bi-box-arrow-right"></i>
        Izloguj se
        </button>
        
    <?php endif;?>

<div id="id01" class="modal">

<form class="modal-content animate" action="reg.php" method="POST">
<div class="imgcontainer">
<span onclick="document.getElementById('id01').style.display='none'" class="close" title="Close Modal">&times;</span>
<img src="Slike/4.PNG" alt="Avatar" class="avatar">
</div>

<div class="container">
<label for="ime"><b>Ime:</b></label>
<input type="text" placeholder="Unesite vase ime" name="ime" id="ime" required>

<label for="password"><b>Lozinka:</b></label>
<input type="password" placeholder="Unesite vasu lozinku" name="password" id="password" required>

<label for="email"><b>Email:</b></label>
<input type="text" placeholder="Unesite vas email" name="email" id="email" required>

<label for="telefon"><b>Telefon:</b></label>
<input type="text" placeholder="Unesite vas telefon" name="telefon" id="telefon" required>

<label for="adresa"><b>Adresa:</b></label>
<input type="text" placeholder="Unesite vasu adtesu" name="adresa" id="adresa" required>
  
<button type="submit">Registruj se</button>

</div>

</form>
</div>



        <?php if(!$_SESSION):?>
        
            <button onclick="document.getElementById('id02').style.display='block'" class="dugme"><i class="bi bi-box-arrow-right"></i>Uloguj se</button>
      
          
          <?php endif;?>

      <div id="id02" class="modal">
  
  <form class="modal-content animate" action="/action_page.php" method="post">
    <div class="imgcontainer">
      <span onclick="document.getElementById('id02').style.display='none'" class="close" title="Close Modal">&times;</span>
      <img src="Slike/4.PNG" alt="Avatar" class="avatar">
    </div>

    <div class="container">
      <label for="ime"><b>Ime:</b></label>
      <input type="text" placeholder="Unesite vase ime" name="ime" required>

      <label for="password"><b>Password</b></label>
      <input type="password" placeholder="Unesite vasu lozinku" name="password" required>
        
      <button type="submit" id="login">Login</button>
      
    </div>
<!-- ------------------------------------------------------------------------------------------------------------------------------- -->
  </form>
</div>
    </ul>
  </div>
  <div id="myBtnContainer">
  <button class="btn active" onclick="filterSelection('all')"> VOLVO</button>
  <button class="btn" onclick="filterSelection('xc')"> XC</button>
  <button class="btn" onclick="filterSelection('sss')"> S</button>
  <button class="btn" onclick="filterSelection('vvv')"> V</button>
</div>

  <div class="row">
      <div class="col-lg-12">
            
            <div class="col-lg-3 filterDiv xc">
                <div class="xc90p col-lg-12">
                    
                </div>

                <div class="xc90t col-lg-12">
                    <p class="text1"><b>VOLVO XC90 D5 MOMENTUM</b><br>
                    već od 36.990 EUR
                    Ili 3 godišnje rate po 12.330 EUR<br></p>

                    <button class="btn-outline-secondary" style="margin-top: 10px;"><a href="http://localhost/WSIT/vozilo.php" class="proba">Pogledajte vozilo</a></button>

                </div>
            </div>
            <div class="col-lg-3 filterDiv xc">
            <div class="xc90p2 col-lg-12">

                </div>

                <div class="xc90t col-lg-12">
                <p class="text1"><b>VOLVO XC90 D4 MOMENTUM</b><br>
                    već od 36.990 EUR
                    Ili 3 godišnje rate po 12.330 EUR <br></p>

                    <button class="btn-outline-secondary" style="margin-top: 10px;">Pogledajte vozilo</button>

                </div>
            </div>
            <div class="col-lg-3 filterDiv xc">
            <div class="xc60p col-lg-12">
                <img src="" alt="">
                </div>

                <div class="xc90t col-lg-12">
                <p class="text1"><b>VOLVO XC60 D5 MOMENTUM</b><br>
                    već od 36.990 EUR
                    Ili 3 godišnje rate po 12.330 EUR <br></p>

                    <button class="btn-outline-secondary" style="margin-top: 10px;">Pogledajte vozilo</button>

                </div>
            </div>
            <div class="col-lg-3 filterDiv xc">
            <div class="xc60p2 col-lg-12">

                </div>

                <div class="xc90t col-lg-12">
                <p class="text1"><b>VOLVO XC60 D4 MOMENTUM</b><br>
                    već od 36.990 EUR
                    Ili 3 godišnje rate po 12.330 EUR <br></p>

                    <button class="btn-outline-secondary" style="margin-top: 10px;">Pogledajte vozilo</button>

                </div>
            </div>
        
                </div>
                <div class=col-lg-12>
                    <div class="col-lg-3 filterDiv sss">
                    <div class="s90p col-lg-12">

                </div>

                <div class="xc90t col-lg-12">
                <p class="text1"><b>VOLVO S90 D5 MOMENTUM</b><br>
                    već od 36.990 EUR
                    Ili 3 godišnje rate po 12.330 EUR <br></p>

                    <button class="btn-outline-secondary" style="margin-top: 10px;">Pogledajte vozilo</button>

                    </div>
                                </div>
                                <div class="col-lg-3 filterDiv sss">
                                <div class="s90p2 col-lg-12">

                    </div>

                <div class="xc90t  col-lg-12">
                <p class="text1"><b>VOLVO S90 D4 MOMENTUM</b><br>
                    već od 36.990 EUR
                    Ili 3 godišnje rate po 12.330 EUR <br></p>

                    <button class="btn-outline-secondary" style="margin-top: 10px;">Pogledajte vozilo</button>

                </div>
            </div>
            <div class="col-lg-3 filterDiv sss">
            <div class="s60p col-lg-12">

                </div>

                <div class="xc90t col-lg-12">
                <p class="text1"><b>VOLVO S60 D5 MOMENTUM</b><br>
                    već od 36.990 EUR
                    Ili 3 godišnje rate po 12.330 EUR <br></p>

                    <button class="btn-outline-secondary" style="margin-top: 10px;">Pogledajte vozilo</button>

                </div>
            </div>
            <div class="col-lg-3 filterDiv sss">
            <div class="s60p2 col-lg-12">

                </div>

                <div class="xc90t col-lg-12">
                <p class="text1"><b>VOLVO S60 D4 MOMENTUM</b><br>
                    već od 36.990 EUR
                    Ili 3 godišnje rate po 12.330 EUR <br></p>

                    <button class="btn-outline-secondary" style="margin-top: 10px;">Pogledajte vozilo</button>

                </div>
            </div>
        </div>

            <div class="col-lg-12">
                <div class="col-lg-3 filterDiv vvv">
                    <div class="v90p col-lg-12">

                    </div>

                    <div class="xc90t col-lg-12">
                    <p class="text1"><b>VOLVO V90 D5 MOMENTUM</b><br>
                        već od 36.990 EUR
                        Ili 3 godišnje rate po 12.330 EUR <br></p>

                        <button class="btn-outline-secondary" style="margin-top: 10px;">Pogledajte vozilo</button>

                    </div>
                </div>
                <div class="col-lg-3 filterDiv vvv">
                    <div class="v90p2 col-lg-12">

                    </div>

                    <div class="xc90t col-lg-12">
                    <p class="text1"><b>VOLVO V90 D4 MOMENTUM</b><br>
                        već od 36.990 EUR
                        Ili 3 godišnje rate po 12.330 EUR <br></p>

                        <button class="btn-outline-secondary" style="margin-top: 10px;">Pogledajte vozilo</button>

                    </div>
                </div>
                <div class="col-lg-3 filterDiv vvv">
                    <div class="v60p col-lg-12">

                    </div>

                    <div class="xc90t col-lg-12">
                    <p class="text1"><b>VOLVO V60 D5 MOMENTUM</b><br>
                        već od 36.990 EUR
                        Ili 3 godišnje rate po 12.330 EUR <br></p>
 
                        <button class="btn-outline-secondary" style="margin-top: 10px;">Pogledajte vozilo</button>

                    </div>
                </div>
                <div class="col-lg-3 filterDiv vvv">
                    <div class="v60p2 col-lg-12">

                    </div>

                    <div class="xc90t col-lg-12">
                    <p class="text1"><b>VOLVO V60 D4 MOMENTUM</b><br>
                        već od 36.990 EUR
                        Ili 3 godišnje rate po 12.330 EUR <br></p>

                        <button class="btn-outline-secondary" style="margin-top: 10px;">Pogledajte vozilo</button>

                    </div>
                </div>
            </div>
            
      

  </div>

  <div class="col-lg-12" style=" height: 500px; background-color: #222831;">
            <div class="col-lg-2" style=" height: 150px;">

            </div>

            <div class="col-lg-8" style="border-bottom: 2px solid  #2c698d; height: 150px;">
                <p class="green">VOLVO</p>
            </div>

            <div class="col-lg-2" style="height: 150px;">

            </div>
            <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d90696.87248172272!2d20.521207099312626!3d44.73435986509258!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x7fd51b4702d8675c!2z0KDQsNGH0YPQvdCw0YDRgdC60Lgg0YTQsNC60YPQu9GC0LXRgiDQo9C90LjQstC10YDQt9C40YLQtdGC0LAg0KPQvdC40L7QvQ!5e0!3m2!1sen!2srs!4v1610541392470!5m2!1sen!2srs" width="800" height="300"  frameborder="0" style="border:0; margin-left:170px; margin-top:20px" allowfullscreen="" aria-hidden="false" tabindex="0"></iframe>
            </div>
            




</div>




        
            
            
            </div>
        
    

</div>
</div>
</nav>




       
</div>

        
<script>
// Get the modal
var modal = document.getElementById('id01');

// When the user clicks anywhere outside of the modal, close it
window.onclick = function(event) {
    if (event.target == modal) {
        modal.style.display = "none";
    }
}

filterSelection("all")
function filterSelection(c) {
  var x, i;
  x = document.getElementsByClassName("filterDiv");
  if (c == "all") c = "";
  for (i = 0; i < x.length; i++) {
    w3RemoveClass(x[i], "show");
    if (x[i].className.indexOf(c) > -1) w3AddClass(x[i], "show");
  }
}

function w3AddClass(element, name) {
  var i, arr1, arr2;
  arr1 = element.className.split(" ");
  arr2 = name.split(" ");
  for (i = 0; i < arr2.length; i++) {
    if (arr1.indexOf(arr2[i]) == -1) {element.className += " " + arr2[i];}
  }
}

function w3RemoveClass(element, name) {
  var i, arr1, arr2;
  arr1 = element.className.split(" ");
  arr2 = name.split(" ");
  for (i = 0; i < arr2.length; i++) {
    while (arr1.indexOf(arr2[i]) > -1) {
      arr1.splice(arr1.indexOf(arr2[i]), 1);     
    }
  }
  element.className = arr1.join(" ");
}

// Add active class to the current button (highlight it)
var btnContainer = document.getElementById("myBtnContainer");
var btns = btnContainer.getElementsByClassName("btn");
for (var i = 0; i < btns.length; i++) {
  btns[i].addEventListener("click", function(){
    var current = document.getElementsByClassName("active");
    current[0].className = current[0].className.replace(" active", "");
    this.className += " active";
  });
}
</script>


</body>
</html>