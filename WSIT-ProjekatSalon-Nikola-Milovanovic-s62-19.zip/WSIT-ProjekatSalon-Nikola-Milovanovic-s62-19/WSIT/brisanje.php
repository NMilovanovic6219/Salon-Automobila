<?php
    require "conection.php";
    $id=$_POST['id'];
    $sql="DELETE FROM korisnici WHERE id = '$id'";
    $stmt=$pdo->prepare($sql);
    $stmt->execute([
    	'id'=>$id
    ]);
?>
<?php
    require "conection.php";
    $id=$_POST['id'];
    $sql="DELETE FROM servis WHERE id = '$id'";
    $stmt=$pdo->prepare($sql);
    $stmt->execute([
    	'id'=>$id
    ]);
?>