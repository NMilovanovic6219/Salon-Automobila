<?php
    $host='localhost';
    $user='root';
    $pass="";
    $database="salon";
    $pdo=new PDO('mysql:host='.$host.';dbname='.$database,$user,$pass);
?>