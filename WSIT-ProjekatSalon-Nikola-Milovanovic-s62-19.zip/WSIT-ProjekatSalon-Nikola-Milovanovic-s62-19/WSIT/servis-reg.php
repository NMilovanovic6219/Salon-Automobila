<?php

require 'conection.php';

$poZelji = $_POST['poZelji'];
$vozilo = $_POST['vozilo'];
$godiste = $_POST['godiste'];
$usr = $_POST['usr'];
$telefonnn = $_POST['telefonnn'];
$prez = $_POST['prez'];
$emailll = $_POST['emailll'];
$datum = $_POST['datum'];

$sqlPrepare="INSERT INTO servis (poZelji,vozilo,godiste,usr,telefonnn,prez,emailll,datum) 
    VALUES (:poZelji, :vozilo, :godiste, :usr, :telefonnn, :prez, :emailll, :datum)";
$stmt=$pdo->prepare($sqlPrepare);
$stmt->execute([
    'poZelji'=>$poZelji,
    'vozilo'=>$vozilo,
    'godiste'=>$godiste,
    'usr'=>$usr,
    'telefonnn'=>$telefonnn,
    'prez'=>$prez,
    'emailll'=>$emailll,
    'datum'=>$datum
]);


header("Location: http://127.0.0.1/WSIT/servis.php");
?>
