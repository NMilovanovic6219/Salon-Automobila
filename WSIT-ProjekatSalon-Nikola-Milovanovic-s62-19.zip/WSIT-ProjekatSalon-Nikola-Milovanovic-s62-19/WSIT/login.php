<?php
    require 'conection.php';

    session_start();
    $ime = $_POST['ime'];
    $password = $_POST['password'];
    $logout = $_POST['logout'];
    $sql="SELECT * FROM korisnici WHERE ime= '$ime' AND password= '$password'";
    $stmt=$pdo->query($sql);
    $user=$stmt->fetch(PDO::FETCH_ASSOC);

    if($user != null){
        if($user['role'] == 1){
            $_SESSION["isAdmin"] = 1;
        }
        else{
            $_SESSION["isAdmin"] = 0;
        }
    }

    if($logout){
        session_destroy();
    }
?>