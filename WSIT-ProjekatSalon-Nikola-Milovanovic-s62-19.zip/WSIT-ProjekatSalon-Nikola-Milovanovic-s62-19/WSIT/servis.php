<?php
	        require 'conection.php';
          session_start();
	        $sql="SELECT * FROM korisnici";
	        $stmt=$pdo-> query($sql);
          $korisnici=$stmt->fetchAll(PDO::FETCH_ASSOC);
	        
   		?> 

           
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Pocetna</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
  <script src="script.js"></script>
    <style>
       

        .div5
        {
            height: 800px;
           
        }
        

        
        body {
            background: url('Slike/prava.svg') no-repeat center center fixed;
            -webkit-background-size: cover;
            -moz-background-size: cover;
            background-size: cover;
            -o-background-size: cover;
        }
        .red
        {
            background-color: #222831!important;
        }
        .green
        {
            color: silver;
            font-size: 75px;
            margin-left: 220px;
            margin-top: 50px;
        }
       

        body {font-family: Arial, Helvetica, sans-serif;}

input[type=text], input[type=password] {
  width: 100%;
  padding: 12px 20px;
  margin: 8px 0;
  display: inline-block;
  border: 1px solid #ccc;
  box-sizing: border-box;
}


button {
  background-color: #222831;
  color: white;
  color: #9d9d9d;
  margin: 8px 0;
  border: none;
  cursor: pointer;
  width: 100%;
}

button:hover {
  opacity: 0.8;
}


.cancelbtn {
  width: auto;
  padding: 10px 18px;
  background-color: #f44336;
}


.imgcontainer {
  text-align: center;
  margin: 24px 0 12px 0;
  position: relative;
}

img.avatar {
  width: 40%;
  border-radius: 50%;
}

.container {
  padding: 16px;
}

span.psw {
  float: right;
  padding-top: 16px;
}


.modal {
  display: none; 
  position: fixed; 
  z-index: 1; 
  left: 0;
  top: 0;
  width: 100%; 
  height: 100%; 
  overflow: auto; 
  background-color: rgb(0,0,0); 
  background-color: rgba(0,0,0,0.4); 
  padding-top: 60px;
}


.modal-content {
  background-color: #fefefe;
  margin: 5% auto 15% auto; 
  border: 1px solid #888;
  width: 80%; 
}


.close {
  position: absolute;
  right: 25px;
  top: 0;
  color: #000;
  font-size: 35px;
  font-weight: bold;
}

.close:hover,
.close:focus {
  color: red;
  cursor: pointer;
}


.animate {
  -webkit-animation: animatezoom 0.6s;
  animation: animatezoom 0.6s
}

@-webkit-keyframes animatezoom {
  from {-webkit-transform: scale(0)} 
  to {-webkit-transform: scale(1)}
}
  
@keyframes animatezoom {
  from {transform: scale(0)} 
  to {transform: scale(1)}
}


@media screen and (max-width: 300px) {
  span.psw {
     display: block;
     float: none;
  }
  .cancelbtn {
     width: 100%;
  }
}
.dugme
{
    width:auto;
    height:35px;
    font-size: 18px!important;

}
.naslov
{
    font-size: 20px;
    margin-left: 50px;
    margin-top: 50px;
    color: silver;
}

.naslov2
{
    font-size: 14px;
    margin-left: 50px;
    margin-top: 50px;
    color: silver;
}
.input
{
    color: silver;
}
.label
{
    color: silver;
    font-size: 14px;
}
.prova
{
    margin-bottom: 45px;
}
.boja
{
  color: silver;
}

#date
{
  margin-left: 30px;
  margin-top: 30px;
  margin-bottom: 30px;
}
    </style>
</head>
<body>

<div class="container">
<div class="row">
<nav class="red navbar navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header">
      <a class="glavni navbar-brand" href="http://localhost/WSIT/index.php">VOLVO</a>
    </div>
    <ul class="nav navbar-nav">
    <li><a href="http://localhost/WSIT/vozila.php">VOZILA</a>
        
      </li>
      <li><a href="http://localhost/WSIT/servis.php">SERVIS</a>
        
      </li>
      
    </ul>
    <ul class="nav navbar-nav navbar-right">





    <?php if(!$_SESSION):?>
        
        <button onclick="document.getElementById('id01').style.display='block'" class="dugme"><i class="bi bi-box-arrow-right"></i>
        Registruj se
        </button>
      <?php else:?>
        <?php if($_SESSION['isAdmin']):?>
          <button id="admin" class="dugme"><i class="bi bi-box-arrow-right"></i>
          <a href="http://localhost/WSIT/admin.php">Admin</a>
        </button>
        <?php endif;?>
        
        <button id="logout" class="dugme"><i class="bi bi-box-arrow-right"></i>
        Izloguj se
        </button>
        
    <?php endif;?>

<div id="id01" class="modal">

<form class="modal-content animate" action="reg.php" method="POST">
<div class="imgcontainer">
<span onclick="document.getElementById('id01').style.display='none'" class="close" title="Close Modal">&times;</span>
<img src="Slike/4.PNG" alt="Avatar" class="avatar">
</div>

<div class="container">
<label for="ime"><b>Ime:</b></label>
<input type="text" placeholder="Unesite vase ime" name="ime" id="ime" required>

<label for="password"><b>Lozinka:</b></label>
<input type="password" placeholder="Unesite vasu lozinku" name="password" id="password" required>

<label for="email"><b>Email:</b></label>
<input type="text" placeholder="Unesite vas email" name="email" id="email" required>

<label for="telefon"><b>Telefon:</b></label>
<input type="text" placeholder="Unesite vas telefon" name="telefon" id="telefon" required>

<label for="adresa"><b>Adresa:</b></label>
<input type="text" placeholder="Unesite vasu adtesu" name="adresa" id="adresa" required>
  
<button type="submit">Registruj se</button>

</div>

</form>
</div>



    <?php if(!$_SESSION):?>
        
        <button onclick="document.getElementById('id02').style.display='block'" class="dugme"><i class="bi bi-box-arrow-right"></i>Uloguj se</button>
      
          
          <?php endif;?>
      <div id="id02" class="modal">
  
  <form class="modal-content animate" action="/action_page.php" method="post">
    <div class="imgcontainer">
      <span onclick="document.getElementById('id02').style.display='none'" class="close" title="Close Modal">&times;</span>
      <img src="Slike/4.PNG" alt="Avatar" class="avatar">
    </div>

    <div class="container">
      <label for="ime"><b>Ime:</b></label>
      <input type="text" placeholder="Unesite vase ime" name="ime" required>

      <label for="password"><b>Password</b></label>
      <input type="password" placeholder="Unesite vasu lozinku" name="password" required>
        
      <button type="submit" id="login">Login</button>
      
    </div>

  </form>
</div>
    </ul>
  </div>

  <!-- ---------------------------------------------------------------------------------------------------------- -->
  <div class="div5 col-lg-12">

  <p class="naslov">Prijava vozila na redovan servis</p>

        <form action="servis-reg.php" method="POST" class="imput">

            <label class="label" for="poZelji">Po zelji dodajte informacije vazne za servis (opis kvara, dodatni zahtevi, drugo)</label>
                <textarea class="form-control" name="poZelji" id="dodaj2" rows="4"></textarea>

                <p class="naslov2">UNESITE PODATKE O SVOM VOZILU</p>
                  <input type="text" placeholder="Unesite model caseg vozila" class="form-control" name="vozilo" id="vozilo">

                  <input type="text" placeholder="Unesite godiste caseg vozila" class="form-control" name="godiste" id="godiste">
                    <br>

                    <div class="boja col-lg-12">
                <p class="naslov2">UNESITE SVOJE KONTAKT PODATKE</p>
                <div class="col-lg-6">
                    
                        
                            <label for="usr">Ime:</label>
                            <input type="text" class="form-control" name="usr" id="usr">
                            
                            <label for="telefonnn">Telefon:</label>
                            <input type="text" class="form-control" name="telefonnn" id="telefonnn">
                        
                    
                </div>


                <div class="col-lg-6">
                    
                        
                            <label for="prez">Prezime:</label>
                            <input type="text" class="form-control" name="prez" id="prez">
                            
                            <label for="email">Email:</label>
                            <input type="text" class="form-control" name="emailll" id="emailll">
                            
                    
                </div>
            </div>

            <p class="naslov2">UNESITE DATUM</p>
              <input type="date" id="date" name="datum">



            <button type="submit" class="btn btn-lg btn-primary">POTVRDITE</button>


        </form>

        



            </div>
            
            <div class="col-lg-12" style=" height: 500px; background-color: #222831;">
            <div class="col-lg-2" style=" height: 150px;">

            </div>

            <div class="col-lg-8" style="border-bottom: 2px solid  #2c698d; height: 150px;">
                <p class="green">VOLVO</p>
            </div>

            <div class="col-lg-2" style="height: 150px;">

            </div>
            <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d90696.87248172272!2d20.521207099312626!3d44.73435986509258!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x7fd51b4702d8675c!2z0KDQsNGH0YPQvdCw0YDRgdC60Lgg0YTQsNC60YPQu9GC0LXRgiDQo9C90LjQstC10YDQt9C40YLQtdGC0LAg0KPQvdC40L7QvQ!5e0!3m2!1sen!2srs!4v1610541392470!5m2!1sen!2srs" width="800" height="300"  frameborder="0" style="border:0; margin-left:170px; margin-top:20px" allowfullscreen="" aria-hidden="false" tabindex="0"></iframe>
            </div>
            




</div>




        
            
            
        
    

</div>
</div>
</nav>




       
</div>

        
<script>
// Get the modal
var modal = document.getElementById('id01');

// When the user clicks anywhere outside of the modal, close it
window.onclick = function(event) {
    if (event.target == modal) {
        modal.style.display = "none";
    }
}
</script>


</body>
</html>
