$(document).ready(function(){
    $("#login").click(function(e){
        e.preventDefault();
        var ime = $("[name='imee']").val();
        var password = $("[name='passwordd']").val();
        
        $.ajax({
            url:"login.php",
            type:"POST",
            data: {ime:ime, password:password},
            success: function(){
                window.location.reload();
            }
        }); 
    });
    

    $("#logout").click(function(){
        var logout = 1;
        $.ajax({
            url:"login.php",
            type:"POST",
            data: {logout:logout},
            success: function(){
                window.location.reload();
            }
        });
    });
    
    $('.btn-delete').click(function(){
        var id = $(this).attr('id');
        console.log(id);
        $.ajax({
            url:"brisanje.php",
            type:"POST",
            data: {id:id},
            success: function(){
                window.location.reload();
            }
        });
    });
});


