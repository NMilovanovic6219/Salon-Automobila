-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 14, 2021 at 09:00 PM
-- Server version: 10.1.37-MariaDB
-- PHP Version: 7.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `salon`
--

-- --------------------------------------------------------

--
-- Table structure for table `korisnici`
--

CREATE TABLE `korisnici` (
  `id` int(11) NOT NULL,
  `ime` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `telefon` varchar(100) NOT NULL,
  `adresa` varchar(100) NOT NULL,
  `role` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `korisnici`
--

INSERT INTO `korisnici` (`id`, `ime`, `password`, `email`, `telefon`, `adresa`, `role`) VALUES
(8, 'admin', 'admin', 'admin@gmail.com', '0605522555', 'Popovo polje', 1),
(9, 'Nikola', '123', 'nmilovanovic@gmail.com', '0655050500', 'popovo polje', 0),
(10, 'Mica', 'mica', 'mica@gmail.com', '0642245852', 'mica@gmail.com', 0),
(11, 'daca', 'daca', 'daca@gmail.com', '0605555555', 'petlovo brdo', 0);

-- --------------------------------------------------------

--
-- Table structure for table `servis`
--

CREATE TABLE `servis` (
  `id` int(11) NOT NULL,
  `poZelji` varchar(255) NOT NULL,
  `vozilo` varchar(100) NOT NULL,
  `godiste` varchar(100) NOT NULL,
  `usr` varchar(100) NOT NULL,
  `telefonnn` varchar(100) NOT NULL,
  `prez` varchar(100) NOT NULL,
  `emailll` varchar(100) NOT NULL,
  `datum` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `servis`
--

INSERT INTO `servis` (`id`, `poZelji`, `vozilo`, `godiste`, `usr`, `telefonnn`, `prez`, `emailll`, `datum`) VALUES
(5, '', 'XC60', '2019', 'Pera', '0645522134', 'Peric', 'pperic@gmail.com', '2021-01-31'),
(6, 'Nesto lupa', 'V90', '2016', 'Djoksi', '065884562', 'Djokic', 'djoksi@gmail.com', '2021-01-28');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `korisnici`
--
ALTER TABLE `korisnici`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `servis`
--
ALTER TABLE `servis`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `korisnici`
--
ALTER TABLE `korisnici`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `servis`
--
ALTER TABLE `servis`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
